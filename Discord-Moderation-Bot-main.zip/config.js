exports.TOKEN = "Njc5NzQ4ODM5NzgzMzk5NDkz.Xk13cA.gpT82LpJY2YQArYvLFm0O--tE_Q";

exports.PREFIX = '*';

exports.OWNER_ID = "527200687172616192"